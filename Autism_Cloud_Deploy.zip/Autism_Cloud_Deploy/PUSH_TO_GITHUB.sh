#!/bin/bash
# Run this script inside your local clone of gurrapusalatejaswini741/Autism
# It copies all cloud-ready files and pushes in one go.

echo "Copying cloud-ready files …"
cp app.py model.py preprocess.py utils.py requirements.txt packages.txt ../
mkdir -p ../.streamlit
cp .streamlit/config.toml ../.streamlit/

cd ..
git add app.py model.py preprocess.py utils.py requirements.txt packages.txt .streamlit/config.toml
git commit -m "feat: Streamlit Cloud deployment ready"
git push origin main
echo "✅ Pushed! Now go to share.streamlit.io to deploy."
